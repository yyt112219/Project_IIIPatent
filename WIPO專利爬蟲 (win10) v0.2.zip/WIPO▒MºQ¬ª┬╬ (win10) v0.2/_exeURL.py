#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MainExe v0.1
author YW
2020.Dec.08
"""
from runDriver import runDriver
from ContentScraper import contentScraper
from time import sleep
import os 



if __name__ == '__main__':
    
    # get all links 
    driver = runDriver(headless=True)
    urls=[]
    i=0
    # os.system('mkdir ./download/')
    start = int(input('input the starting page: \n'))
    end = int(input('input the end page: \n'))
    if driver.connector():
        while i<end+1:         
            sleep(10)
            urls=driver.getUrls()
            driver.next_page()            
            print('The num of scraped urls:',len(urls))

            with open(f'./download/url_{i}.txt','a') as f:
                for line in urls:
                    f.write(line+'\n')
            print(f'urls writen to ./download/url_{i}.txt')
            i=i+1
            
    
    driver.closeDriver()

""" 爬完連結再執行
    # get IP content
    wipo='https://patentscope.wipo.int/search/en/detail.jsf?docId='
    with open('./download/url.txt' 'r') as f:
        urls=f.readlines()
    driver = contentScraper(headless=True)
    for url in urls:
        if driver.connector(a=wipo+url):
            MainTitle=driver.getMiainTitle()
            SubTitle=driver.getSubTitiles()
            PublicNum=driver.getPublicationNumber()
            PublicDate=driver.getPublicationDate()
            IAN=driver.getInternationalApplicationNo()
            IFD=driver.getInternationalFilingDate()
            IPC=driver.getIPC()
            Applicants=driver.getApplicants()
            Inventors=driver.getInventors()
            Agents=driver.getAgents()
            DesignedStates=driver.getDesignedStates()
            Abstracts=driver.getAbstract()
            
            with open(f'./download/IP contents/{PublicNum.replace("/","")}.csv','a') as f:
                text=f'"{MainTitle}","{SubTitle}","{PublicNum}","{PublicDate}","{IAN}","{IFD}","{IPC}","{Applicants}","{Inventors}","{Agents}","{DesignedStates}"'
                f.write(text)
            with open(f'./download/IP contents/Abstract_{PublicNum.replace("/","")}.txt','w') as f:
                abstract=f'"{Abstracts}"'
                f.write(abstract)
            

    driver.closeDriver()
"""