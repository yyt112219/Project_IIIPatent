# -*- coding: utf-8 -*-
"""
runDriver v0.1
author YW
2020.Dec.08
"""
from selenium import webdriver
import os#, re
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
# from tqdm import tqdm


class runDriver():
    """
    Return a object selenium.webdriver.
    ep: the path of chromedriver.
    headless: open with headless or not.
    """
    def __init__(self,ep="./chromedriver",headless=False):
        options = webdriver.ChromeOptions()
        if headless: options.add_argument("--headless");
        options.add_argument("--start-maximized")
        self.driver= webdriver.Chrome(executable_path=ep,options=options);


    def closeDriver(self):
        self.driver.close()
     
    
    def connector(self,a="https://patentscope.wipo.int/search/en/search.jsf"):
        """
        driver: A selenium.webdriver objects
        a: url
        -------------------------------------
        Description:
        The driver will connect to WIPO-PCT query page, then click the search button without inputing any keyword.
        -------------------------------------
        return bool.
        """
        success = False;
        try:
            self.driver.get(a)
            self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[2]/form/div/div[1]/div[2]/div/div/div[1]/div[2]/button').click()
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[2]/div/select[1]').click() # cilck to select the num of showing IPs on a page.
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[2]/div/select[1]/option[4]').click()
            success = True     
        except Exception as e:
            print(e)
        if success:
            return success
    
    
    def getUrls(self, page=1):
        """
        page can be set as the broken point of last runtime.
        return list(string), url inside
    
        please add the host url manually:
            "https://patentscope.wipo.int/search/en/detail.jsf?docId="
        """
        urls = []
        # for item in self.driver.find_elements_by_css_selector('div[class="ps-patent-result--title"] span[class="notranslate ps-patent-result--title--record-number"] a'):
        #     urls.append(item.get_attribute('href'))
        if (page>1): # go to specific page
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[2]/div/a').click()
            inputPage = self.driver.find_element_by_xpath('/html/body/div[2]/div[2]/div/div/div/form/input[2]')
            inputPage.send_keys(Keys.CONTROL, 'a')
            inputPage.send_keys(Keys.BACK_SPACE)
            inputPage.send_keys(str(page))
            inputPage.send_keys(Keys.ENTER)
            sleep(1)
            self.driver.find_element_by_xpath('/html/body/div[2]/div[2]/div/div/div/form/button').click() # cilck go to page
            sleep(10)
        print('parsing urls....')
        for i in range(1,201):
            url=self.driver.find_element_by_xpath(f'/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[2]/div/div[1]/div/div/table/tbody/tr[{i}]/td/div/div[1]/div[1]/a')
            urls.append(url.get_attribute('href').replace('https://patentscope.wipo.int/search/en/detail.jsf?docId=', ''))

        return urls
    
    def next_page(self):
        # btn=self.driver.find_elements_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[2]/div/div[2]/div/a/span')
        btn=self.driver.find_elements_by_css_selector('a[title="Next Page"]')

        if len(btn)>0:
            btn[0].click()



if __name__ == '__main__':
    urls=[]
    driver = runDriver()
    if driver.connector():
        sleep(10)
        urls=driver.getUrls(3)
        driver.next_page()
    
    print('The num of scraped urls:',len(urls))
    try:
        os.system('mkdir ./download/')
    except:
        print('The directory is already existed.')
    finally:
        with open('./download/url.txt','a') as f:
            for line in urls:
                f.write(line+'\n')
        print('urls writen to ./download/url.txt')
            
    
    driver.closeDriver()
