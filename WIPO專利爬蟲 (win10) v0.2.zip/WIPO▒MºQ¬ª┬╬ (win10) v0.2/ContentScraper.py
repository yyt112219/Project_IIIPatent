#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Content Scraper v0.1
author YW
2020.Dec.08
"""
from runDriver import runDriver


class contentScraper(runDriver):
    
    def connector(self,a="https://patentscope.wipo.int/search/en/search.jsf"):
        """
        driver: A selenium.webdriver objects
        a: url
        -------------------------------------
        Description:
        The driver will connect to WIPO-PCT query page, then click the search button without inputing any keyword.
        -------------------------------------
        return bool.
        """
        success = False;
        try:
            self.driver.get(a)
            success = True     
        except Exception as e:
            print(e)
        if success:
            return success

    def getMiainTitle(self):
        return self.driver.find_element_by_css_selector('div[class="ps-page-header--subtitle--text"]').text
    
    def getSubTitiles(self):
        result=[]
        blk = self.driver.find_elements_by_css_selector('span[class="ps-field--value ps-biblio-field--value"] \
                                                        div[class="patent-title"] \
                                                            span[class="PCTtitle"] \
                                                                div')
                                                          
        for i in blk:
            lang=i.find_element_by_css_selector('b[class="notranslate"]').text
            title=i.find_element_by_css_selector('span').text
            result.append((lang,title))
        
        return result
    def getPublicationNumber(self):
        return self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[1]/span[2]/span').text
    
    def getPublicationDate(self):
        return self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[2]/span[2]/span').text
    
    def getInternationalApplicationNo(self):
        return self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[3]/span[2]').text
    
    def getInternationalFilingDate(self):
        return self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[4]/span[2]').text
    
    def getIPC(self):
        ipc=[]
        blk=self.driver.find_element_by_css_selector('div[class="ps-field ps-biblio-field ipc-biblio-field"]')
        blk=blk.find_elements_by_css_selector('span[class="ps-field--value ps-biblio-field--value"] \
                                              div \
                                                  div[class="ps-expand-content--collapsed"] \
                                                      div[class="patent-classification"]')
        for i in blk:
            items=i.find_elements_by_css_selector('span span span')
            ipc.append((items[0].find_element_by_css_selector('a').text,items[1].text))
        return ipc

    def getApplicants(self):
        names=[]
        blk=self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[6]')
        blk=blk.find_elements_by_css_selector('span[class="ps-field--value ps-biblio-field--value"] \
                                              span[class="patent-person notranslate"] \
                                                  ul[class="biblio-person-list"] \
                                                      li')
        for i in blk:
            firm = i.find_element_by_css_selector('span[class="biblio-person-list--name"]').text
            country= i.text.replace(firm,'')
            names.append((firm,country))
        return names

    
    def getInventors(self):
        blk=self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[7]')
        blk=blk.find_elements_by_css_selector('span[class="ps-field--value ps-biblio-field--value"] \
                                              span[class="patent-person notranslate"] \
                                                  ul[class="biblio-person-list"] li')
        return [name.text for name in blk]
    
    def getAgents(self):
        blk=self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[8]')
        blk=blk.find_elements_by_css_selector('span[class="ps-field--value ps-biblio-field--value"] \
                                              span[class="patent-person notranslate"] \
                                                  ul[class="biblio-person-list"] li')
        return [name.text for name in blk]
    
    def getDesignedStates(self):
        self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[12]/span[2]/div/div[1]/div/a/span').click()
        return self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[1]/div[12]/span[2]/div/div[2]/span').text

    def getAbstract(self):
        abstracts=[]
        blk=self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[1]/div/form/div[2]/div/div[2]/div/div/div[2]/div[3]')
        blk=blk.find_elements_by_css_selector('span[class="ps-field--value ps-biblio-field--value"]')
        for i in blk:
            lang=i.find_elements_by_css_selector('b')
            text=i.find_elements_by_css_selector('div[class="trans-section NPabstract"]')
            for j in range(len(lang)):
                abstracts.append((lang[j].text,text[j].text))
        
        return abstracts
            









if __name__ == '__main__':
    urls=[]
    driver = contentScraper(headless=True)
    if driver.connector(a='https://patentscope.wipo.int/search/en/detail.jsf?docId=WO2020237407&tab=PCTBIBLIO'):
        print(driver.getMiainTitle())
        print(driver.getSubTitiles())
        print(driver.getPublicationNumber())
        print(driver.getPublicationDate())
        print(driver.getInternationalApplicationNo())
        print(driver.getInternationalFilingDate())
        print(driver.getIPC())
        print(driver.getApplicants())
        print(driver.getInventors())
        print(driver.getAgents())
        print(driver.getDesignedStates())
        print(driver.getAbstract())
    
        
        

            
    
    driver.closeDriver()
                                                                   
        
        
            
        
        