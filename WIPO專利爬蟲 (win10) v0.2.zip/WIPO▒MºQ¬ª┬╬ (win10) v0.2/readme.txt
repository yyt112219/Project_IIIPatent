1. 在win 10 環境中，cd至程式的位置，以 python ./_exeURL.py 執行程式。
        1.1 chromedriver版本為87，若有不同自行更新並放置在程式資料夾內
        1.2 chromedriver預設為背景執行，可至_exe內自行修改 headless = False
2. 建議爬完url後，再爬IP內容
3. _exeURL.py 需要輸入欲抓取的開始頁數及結束頁數
        3.1 下載後的url.txt放在download資料夾內
4. _exeIP.py需要讀取要下載的url，請使用cmder工具，利用 cat url_0.txt url_1.txt > ./download/url.txt 合併需要下載的url清單
        4.1 ./download/url.txt 為預設檔名及路徑，建議不要更改。
        4.2 若有需要更改，至_exeIP.py內修改

