#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MainExe v0.1
author YW
2020.Dec.08
"""
from runDriver import runDriver
from ContentScraper import contentScraper
from time import sleep
import os 



if __name__ == '__main__':
#""" 爬完連結再執行
    # get IP content
    wipo='https://patentscope.wipo.int/search/en/detail.jsf?docId='
    with open('./download/url.txt', 'r') as f:
        urls=f.readlines()
    driver = contentScraper(headless=True)
    for url in urls:
        if driver.connector(a=wipo+url):
            try:
                MainTitle=driver.getMiainTitle()
                SubTitle=driver.getSubTitiles()
                PublicNum=driver.getPublicationNumber()
                PublicDate=driver.getPublicationDate()
                IAN=driver.getInternationalApplicationNo()
                IFD=driver.getInternationalFilingDate()
                IPC=driver.getIPC()
                Applicants=driver.getApplicants()
                Inventors=driver.getInventors()
                Agents=driver.getAgents()
                DesignedStates=driver.getDesignedStates()
            except Exception as e:
                with open(f'./download/IP contents/log_unable.txt','a',encoding='utf-8') as f:
                    f.write(f'{PublicNum.replace("/","")}, {e}\n')
                continue
            Abstracts=driver.getAbstract()
            
            with open(f'./download/IP contents/{PublicNum.replace("/","")}.csv','a', encoding='utf-8') as f:
                text=f'"{MainTitle}","{SubTitle}","{PublicNum}","{PublicDate}","{IAN}","{IFD}","{IPC}","{Applicants}","{Inventors}","{Agents}","{DesignedStates}"'
                f.write(text)
            with open(f'./download/IP contents/Abstract_{PublicNum.replace("/","")}.txt','w',encoding='utf-8') as f:
                abstract=f'"{Abstracts}"'
                f.write(abstract)
				
            with open(f'./download/IP contents/log.txt','a',encoding='utf-8') as f:
                f.write(f'{PublicNum.replace("/","")}\n')
            

    driver.closeDriver()
#"""