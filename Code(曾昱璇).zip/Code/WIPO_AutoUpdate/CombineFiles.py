import os
import pathlib
import glob
from os import listdir
from os.path import isfile, join
from datetime import date

#current path of .py script
filepath=pathlib.Path(__file__).parent.absolute()
filepath = str(filepath)+"\\test"

files = [os.path.join(r,file) for r,d,f in os.walk(filepath) for file in f]

today = date.today()
date = today.strftime("%Y%m%d")

with open('./Updates/' + str(date) + 'Latest_Update.txt', 'w') as outfile:
    for fname in files:
        with open(fname) as infile:
            for line in infile:
                outfile.write(line)


files = glob.glob('./test/*')
for f in files:
    os.remove(f)