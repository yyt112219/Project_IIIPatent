# -*- coding: utf-8 -*-
"""
autoScraper v0.1
author Sunny T.
2020.Dec.20
"""

from selenium import webdriver
import os
import glob
from pathlib import Path
from time import sleep
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from datetime import date
from os import listdir
from os.path import isfile, join


class autoScraper():
    def __init__(self,ep="./chromedriver",headless=False):
        options = webdriver.ChromeOptions()
        if headless: options.add_argument("--headless");
        options.add_argument("--start-maximized")
        self.driver= webdriver.Chrome(executable_path=ep,options=options);


    def closeDriver(self):
        self.driver.close()
        
    def next_page(self):
        # btn=self.driver.find_elements_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[2]/div/div[2]/div/a/span')
        btn=self.driver.find_elements_by_css_selector('a[title="Next Page"]')

        if len(btn)>0:
            btn[0].click()
            
    def connector(self,a="https://patentscope.wipo.int/search/en/search.jsf"):
        success = False;
        try:
            self.driver.get(a)
            self.driver.find_element_by_xpath('/html/body/div[2]/div[5]/div/div[2]/form/div/div[1]/div[2]/div/div/div[1]/div[2]/button').click()
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[2]/div/select[1]').click() # cilck to select the num of showing IPs on a page.
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[2]/div/select[1]/option[4]').click()
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[1]/div/select[1]/option[2]').click()
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[2]/div/select[1]/option[4]').click()
            self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[1]/div/div[1]/div[3]/div/select[1]/option[2]').click()
            success = True     
        except Exception as e:
            print(e)
        if success:
            return success
        
    def writeLast(self):    
        with open("./test/App_No.1.txt", "r") as f:
            first_line = f.readline()

        print(first_line)

        with open('last.txt', "w") as f:
            last_PCT = f.write(first_line)
        
        return
    
    def getPCT(self, repeat):
        PCT = []
        with open('last.txt', "r") as f:
            lastPCT = f.readline().strip()
            
        for i in range(1,201):
            no = self.driver.find_element_by_xpath('/html/body/div[2]/div[4]/div/div[1]/div[2]/div/form[2]/div/div[1]/div/div/table/tbody/tr[%s]/td/div/div[2]/div/div[1]/span[2]/span[2]' %(i)).text
            if no == lastPCT:
                repeat=True
                break
            else:
                PCT.append(no)

        return PCT, repeat

    def writeFile(self):
        with open('./test/App_No.'+str(i)+'.txt','a') as f:
            for line in PCT:
                f.write(line+'\n')
        return 

                        
if __name__ == '__main__':
    PCT=[]
    driver = autoScraper()
    repeat=False
    if driver.connector():
        i=0  
        while i<100:
            sleep(10)
            i=i+1
            PCT, repeat = driver.getPCT(repeat)
            if repeat == True:
                driver.writeFile()
                driver.writeLast()
                print('Replaced last.txt')
                break
            else:
                driver.writeFile()
                driver.next_page()
                
    driver.closeDriver()