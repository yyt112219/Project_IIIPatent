import pandas as pd
import numpy as np
import os
import mysql.connector
from sqlalchemy import create_engine
import plotly
import plotly.express as px


mariadb=mysql.connector.connect(
host = "10.120.31.57",
user = "hadoop",
database="bdse16",
password="hadoop"
)
cursor=mariadb.cursor()

cursor.execute("SELECT * FROM ipc_hierarchy_pivot")
result = cursor.fetchall()
data = np.array(result)
df = pd.DataFrame(data, columns = ['ids', 'groups','level','count'])
df.insert(0,'total','Total')

fig = px.treemap(df, 
                 path=['total','ids', 'groups', 'level'], 
                 values='count',
                 width=1000, 
                 height=650
)
fig.update_traces(
    hovertemplate="<br>".join([
        "Class: %{label}",
        "Count: %{value}",
        "Path: %{id}",
        "Percentage of All Patents: %{percentEntry:.2%f}",
        "Percentage: %{percentParent:.2%f}",
    ]),
    texttemplate="<br>".join([
        "%{label}",
        "%{value}",
        "%{percentParent:%f}",
    ]),
    textfont=dict(
        size=14,
        color='white'
    )

)
fig.update_layout(
                  title=dict(
                      text="<b>Patents & Classifications</b>",
                      x= 0.083,
                      y= 0.95,
                      xanchor='left',
                      yanchor='top'),
                  plot_bgcolor='rgba(0,0,0,0)',
                  treemapcolorway = ['rgb(89, 112, 128, 0.5)',
                                     'rgb(109, 161, 138, 0.5)',
                                     'rgb(84, 103, 153, 0.5)',
                                     'rgb(102, 153, 204, 0.5)',
                                     'rgb(196, 115, 108, 0.5)',
                                     'rgb(189, 85, 95, 0.5)',
                                     'rgb(140, 63, 82, 0.5)',
                                     'rgb(102, 41, 76, 0.5)'])

plotly.offline.plot(fig, filename='TreeMap2.html')