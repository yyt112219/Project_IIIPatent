import pandas as pd
import numpy as np
import os
import mysql.connector
from sqlalchemy import create_engine
import plotly
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


mariadb=mysql.connector.connect(
host = "10.120.31.57",
user = "hadoop",
database="bdse16",
password="hadoop"
)
cursor=mariadb.cursor()

cursor.execute("SELECT * FROM timeSeries_map")
result = cursor.fetchall()
data = np.array(result)
df = pd.DataFrame(data, columns = ['Date', 'A','B','C','D','E','F','G','H'])
df['Date'] = pd.to_datetime(df['Date'])
df[['A','B','C','D','E','F','G','H']] = df[['A','B','C','D','E','F','G','H']].apply(pd.to_numeric)
df['Patents']=df['A']+df['B']+df['C']+df['D']+df['E']+df['F']+df['G']+df['H']

fig = make_subplots(specs=[[{"secondary_y": True}]])

Total=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.Patents),name='Patents',line=dict(color="rgba(51, 26, 51, 0.6)",dash='dashdot',width=4)),secondary_y=True)
A=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.A),name='A_Human Necessities',line=dict(color="rgba(89, 112, 128, 0.6)",width=3)),secondary_y=False)
B=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.B),name='B_Performing Operations;Transportation',line=dict(color="rgba(109, 161, 138, 0.6)",width=3)),secondary_y=False)
C=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.C),name='C_Chemistry; Metallurgy',line=dict(color="rgba(84, 103, 153, 0.6)",width=3)),secondary_y=False)
D=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.D),name='D_Textiles; Paper',line=dict(color="rgba(102, 153, 204, 0.6)",width=3)),secondary_y=False)
E=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.E),name='E_Fixed Constructions',line=dict(color="rgba(196, 115, 108, 0.6)",width=3)),secondary_y=False)
F=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.F),name='F_Mechnical Engineering',line=dict(color="rgba(189, 85, 95, 0.6)",width=3)),secondary_y=False)
G=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.G),name='G_Physics',line=dict(color="rgba(140, 63, 82, 0.6)",width=3)),secondary_y=False)
H=fig.add_trace(go.Scatter(x=list(df.Date), y=list(df.H),name='H_Electricity',line=dict(color="rgba(102, 41, 76, 0.6)",width=3)),secondary_y=False)


fig.update_layout(
    updatemenus=[
        dict(buttons=list([
                dict(label="All",
                     method="update",
                     args=[{"visible": [True,True,True,True,True,True,True,True,True]},
                           {"title_text": "All"}]),
                dict(label="Patents",
                     method="update",
                     args=[{"visible": [True,False,False,False,False,False,False, False,False]},
                           {"title_text": "Patents"}]),
                dict(label="A",
                     method="update",
                     args=[{"visible": [False,True, False,False,False,False,False,False,False]},
                           {"title_text": "A"}]),
                dict(label="B",
                     method="update",
                     args=[{"visible": [False,False,True,False,False,False,False,False,False]},
                           {"title_text": "B"}]),
                dict(label="C",
                     method="update",
                     args=[{"visible": [False,False,False,True,False,False,False,False,False]},
                           {"title_text": "C"}]),
                dict(label="D",
                     method="update",
                     args=[{"visible": [False,False,False,False,True,False,False,False,False]},
                           {"title_text": "D"}]),
                dict(label="E",
                     method="update",
                     args=[{"visible": [False,False,False,False,False,True,False,False,False]},
                           {"title_text": "E"}]),
                dict(label="F",
                     method="update",
                     args=[{"visible": [False,False,False,False,False,False,True,False,False]},
                           {"title_text": "F"}]),
                dict(label="G",
                     method="update",
                     args=[{"visible": [False,False,False,False,False,False,False,True,False]},
                           {"title_text": "G"}]),
                dict(label="H",
                     method="update",
                     args=[{"visible": [False,False,False,False,False,False,False,False,True]},
                           {"title_text": "H"}]),

            ]),
            direction="down",
            pad={"r": 1, "t": 1},
            showactive=True,
            x=0.005,
            xanchor="left",
            y=1.15,
            yanchor="top"
        ),
    ]
)

fig.update_layout(
    title=dict(
        text="<b>A History of Patents & Classifications</b>",
        x= 0.05,
        y= 0.96,
        xanchor='left',
        yanchor='top'),
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1),
    showlegend=True,
    plot_bgcolor='rgba(0,0,0,0)',
    autosize=False,
    width=1000,
    height=650,
)

fig.update_traces(
    hovertemplate="<br>".join([
        "Year: %{x}",
        "Count: %{y}",
    ]),
)


fig.update_xaxes(
    title_text='Time',
    dtick="M12",
    tickformat="%Y",
    tickangle=-45,
    type="date",
    rangeslider_visible=True,
    showgrid=True,
    gridwidth=1, 
    gridcolor='rgba(218, 218, 218, 0.6)',
    showspikes=True,
    spikethickness=2,
    spikesnap="cursor", 
    spikemode="across",
    tickformatstops = [
        dict(dtickrange=["M1", "M10"], value="%b '%y"),
        dict(dtickrange=["M6", "M12"], value="%Y")
    ]
)

fig.update_yaxes(
    title_text='<b>Class</b> <br> Values',
    dtick=50,
    tick0=0.0,
    showgrid=True,
    gridwidth=1, 
    gridcolor='rgba(218, 218, 218, 0.6)',
    showspikes=True,
    spikethickness=2,
    secondary_y=False)

fig.update_yaxes(
    title_text='<b>Patent</b> <br>Values',
    dtick=200,
    tick0=0.0,
    showgrid=True,
    gridwidth=1, 
    gridcolor='rgba(218, 218, 218, 0.6)',
    showspikes=True,
    spikethickness=2,
    secondary_y=True)
fig.show()

plotly.offline.plot(fig, filename='TimeSeries.html')