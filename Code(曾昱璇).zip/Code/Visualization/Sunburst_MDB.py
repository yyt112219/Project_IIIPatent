import pandas as pd
import numpy as np
import os
import plotly
import plotly.express as px
import mysql.connector
from sqlalchemy import create_engine

mariadb=mysql.connector.connect(
host = "10.120.31.57",
user = "hadoop",
database="bdse16",
password="hadoop"
)
cursor=mariadb.cursor()

cursor.execute("SELECT * FROM ipc_hierarchy_pivot")
result = cursor.fetchall()

data = np.array(result)
df = pd.DataFrame(data, columns = ['ids', 'groups','level','count'])

fig = px.sunburst(df, path=['ids', 'groups'], values='count',)

fig.update_traces(
    hovertemplate="<br>".join([
        "Class: %{label}",
        "Count: %{value}", 
        "Percent of All Patents: %{percentEntry:.2%f}",
        "Percentage:%{percentParent:%f}"
    ]),
    texttemplate="<br>".join([
        "%{label}",
        "%{percentParent:%f}",
    ]),
    textfont=dict(
        size=14,
        color='white'
    ),
    insidetextorientation='horizontal',
    
)
fig.update_layout(coloraxis_colorbar_title='Count',
                  title_text="Patent Classifications",
                  sunburstcolorway = ['rgb(89, 112, 128, 0.5)',
                                     'rgb(109, 161, 138, 0.5)',
                                     'rgb(84, 103, 153, 0.5)',
                                     'rgb(102, 153, 204, 0.5)',
                                     'rgb(196, 115, 108, 0.5)',
                                     'rgb(189, 85, 95, 0.5)',
                                     'rgb(140, 63, 82, 0.5)',
                                     'rgb(102, 41, 76, 0.5)'])

plotly.offline.plot(fig, filename='Sunburst.html')